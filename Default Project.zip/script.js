// Portfolio interactions
(function(){
  "use strict";
  const $ = (s,c=document)=>c.querySelector(s);
  const $$ = (s,c=document)=>[...c.querySelectorAll(s)];

  // Preloader
  window.addEventListener('load',()=>setTimeout(()=>$('#preloader')?.classList.add('hide'),450));
  setTimeout(()=>$('#preloader')?.classList.add('hide'),2500); // failsafe

  // Year
  $('#year').textContent = new Date().getFullYear();

  // Scroll progress + navbar hide + back-to-top
  const nav = $('#mainNav'), bar = $('#scrollProgress'), backTop = $('#backTop');
  let lastY = 0;
  const onScroll = ()=>{
    const y = window.scrollY;
    const h = document.documentElement.scrollHeight - innerHeight;
    bar.style.width = (h>0? (y/h*100):0)+'%';
    if(y>400 && y>lastY+4) nav.classList.add('hide'); else if(y<lastY-4||y<400) nav.classList.remove('hide');
    lastY=y;
    backTop.classList.toggle('show', y>600);
  };
  addEventListener('scroll',onScroll,{passive:true}); onScroll();
  backTop.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));

  // Active nav highlighting
  const links = $$('#mainNav .nav-link');
  const secs = links.map(a=>$(a.getAttribute('href'))).filter(Boolean);
  const io = new IntersectionObserver(es=>{
    es.forEach(e=>{ if(e.isIntersecting){
      links.forEach(a=>a.classList.toggle('active', a.getAttribute('href')==='#'+e.target.id));
    }});
  },{rootMargin:'-40% 0px -55% 0px'});
  secs.forEach(s=>io.observe(s));

  // Mobile nav auto-close
  $$('.navbar-collapse .nav-link, .navbar-collapse .btn').forEach(a=>a.addEventListener('click',()=>{
    const c = $('#navMenu'); if(c.classList.contains('show')) bootstrap.Collapse.getInstance(c)?.hide();
  }));

  // Reveal on scroll
  const rio = new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('visible'); rio.unobserve(e.target);} }),{threshold:.12});
  $$('.reveal').forEach(el=>rio.observe(el));

  // Skill bars animate
  const bio = new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){
    $$('.fill',e.target).forEach(f=>f.style.width=f.dataset.w+'%'); bio.unobserve(e.target);
  }}),{threshold:.3});
  $$('.skillbar-wrap').forEach(el=>bio.observe(el));

  // Counters
  const cio = new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){
    const el=e.target, end=+el.dataset.count; let cur=0; const step=Math.max(1,Math.round(end/60));
    const t=setInterval(()=>{ cur+=step; if(cur>=end){cur=end;clearInterval(t);} el.textContent=cur+(el.dataset.suffix||''); },28);
    cio.unobserve(el);
  }}),{threshold:.6});
  $$('[data-count]').forEach(el=>cio.observe(el));

  // Typing effect
  const words=['Gym Management Systems','PHP + MySQL CRUD Apps','Payroll + FPDF Payslips','Laravel 13 Rebuilds','Responsive Bootstrap UIs'];
  const typedEl=$('#typed'); let wi=0,ci=0,del=false;
  (function tick(){
    if(!typedEl) return;
    const w=words[wi];
    typedEl.textContent=w.slice(0,ci);
    if(!del){ ci++; if(ci>w.length){del=true;return setTimeout(tick,1400);} }
    else{ ci--; if(ci===0){del=false;wi=(wi+1)%words.length;} }
    setTimeout(tick, del?32:68);
  })();

  // Card spotlight follows mouse
  $$('.bento-card').forEach(c=>c.addEventListener('mousemove',e=>{
    const r=c.getBoundingClientRect();
    c.style.setProperty('--mx',(e.clientX-r.left)+'px');
    c.style.setProperty('--my',(e.clientY-r.top)+'px');
  }));

  // Project filtering
  $$('.filter-btn').forEach(b=>b.addEventListener('click',()=>{
    $$('.filter-btn').forEach(x=>x.classList.remove('active')); b.classList.add('active');
    const f=b.dataset.filter;
    $$('.proj-col').forEach(col=>{
      const show = f==='all' || col.dataset.cat===f;
      col.style.display=show?'':'none';
      if(show){ col.classList.remove('visible'); requestAnimationFrame(()=>requestAnimationFrame(()=>col.classList.add('visible'))); }
    });
  }));

  // Cursor glow (desktop only, respects reduced motion)
  const glow=$('#cursorGlow');
  if(glow && matchMedia('(pointer:fine)').matches && !matchMedia('(prefers-reduced-motion: reduce)').matches){
    addEventListener('mousemove',e=>{ glow.style.left=e.clientX+'px'; glow.style.top=e.clientY+'px'; },{passive:true});
  } else glow?.remove();

  // Contact form demo
  $('#contactForm')?.addEventListener('submit',e=>{
    e.preventDefault();
    const form=e.target;
    if(!form.checkValidity()){ form.classList.add('was-validated'); return; }
    const btn=$('#sendBtn'); btn.disabled=true; btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>Sending...';
    setTimeout(()=>{
      btn.innerHTML='<i class="bi bi-check-circle me-2"></i>Message Sent!';
      $('#formMsg').classList.remove('d-none');
      form.reset(); form.classList.remove('was-validated');
      setTimeout(()=>{btn.disabled=false;btn.innerHTML='<i class="bi bi-send me-2"></i>Send Message';},3000);
    },1100);
  });

  // Copy email
  $('#copyEmail')?.addEventListener('click',async()=>{
    try{ await navigator.clipboard.writeText('hello@yourname.dev');
      const t=$('#copyEmail'); t.innerHTML='<i class="bi bi-check"></i>'; setTimeout(()=>t.innerHTML='<i class="bi bi-clipboard"></i>',1500);
    }catch{}
  });

  // Theme: subtle toggle dark/deeper (keeps dark-modern identity)
  $('#themeBtn')?.addEventListener('click',()=>{
    document.body.classList.toggle('light-soft');
  });
})();
